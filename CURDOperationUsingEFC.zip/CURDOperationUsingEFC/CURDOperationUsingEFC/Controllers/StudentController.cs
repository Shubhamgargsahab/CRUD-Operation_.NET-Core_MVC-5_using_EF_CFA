﻿using CURDOperationUsingEFC.DataModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CURDOperationUsingEFC.Controllers
{
    public class StudentController : Controller
    {

        private readonly StudentContext _Db;

        public StudentController(StudentContext db)
        {
            _Db = db;
        }
    
        public IActionResult StudentList()
        {
            try
            {
                // var stdList = _Db.tbl_Student.ToList(); // if we need to get data from single table use this.

                //here we need to fetch the data from 2 or multiple table so here we use join.
                var stdList = from a in _Db.tbl_Student // a is the alias of student table
                              join b in _Db.tbl_Departments // b is the alias of dept table
                              on a.DepID equals b.ID
                              into Dep
                              from b in Dep.DefaultIfEmpty()
                              select new Student
                              {
                                  ID = a.ID,
                                  Name = a.Name,
                                  FName = a.FName,
                                  Mobile = a.Mobile,
                                  Email = a.Email,
                                  Description = a.Description,
                                  DepID = a.DepID,

                                  Department = b == null ? "" : b.Department
                              };

                return View(stdList);
            }
            catch (System.Exception)
            {

                throw;
            }

        }
    
    public IActionResult Create(Student student)
        {
            loadDDL();
            return View(student);
        }

        //Data save karne kia jo method bante hai vo asyn hota hai or unhi hum task me rakhte hai
        [HttpPost]
        public async Task<IActionResult> AddStudent(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (student.ID == 0)
                    {
                        _Db.tbl_Student.Add(student);
                        await _Db.SaveChangesAsync();
                    }
                    else
                    {
                        _Db.Entry(student).State = EntityState.Modified;
                        await _Db.SaveChangesAsync();
                    }

                    return RedirectToAction("StudentList");
                }
                return View();
            }
            catch (System.Exception)
            {
                return RedirectToAction("StudentList");
                throw;
            }
        }
   
    private void loadDDL()
        {
            try
            {
                List<Departments> deplist = new List<Departments>();
                deplist = _Db.tbl_Departments.ToList();
                deplist.Insert(0, new Departments { ID = 0, Department = "Please Select" });

                ViewBag.deplist = deplist;
            }
            catch (System.Exception)
            {

                throw;
            }
        }


        public async Task<IActionResult> DeleteStudent(int id)
        {
            try
            {

                var std =  _Db.tbl_Student.Find(id);
                if (std!=null)
                {
                    _Db.tbl_Student.Remove(std);
                    await _Db.SaveChangesAsync();   
                }
                return RedirectToAction("StudentList");
            }
            catch (System.Exception)
            {
                return RedirectToAction("StudentList");
            }
        }
    }
}
