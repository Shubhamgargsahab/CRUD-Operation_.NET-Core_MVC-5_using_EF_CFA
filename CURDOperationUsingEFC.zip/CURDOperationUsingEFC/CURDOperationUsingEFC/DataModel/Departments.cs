﻿using System.ComponentModel.DataAnnotations;

namespace CURDOperationUsingEFC.DataModel
{
    public class Departments
    {
        [Key]
        public int ID { get; set; }
        public string Department { get; set; }
    }
}
